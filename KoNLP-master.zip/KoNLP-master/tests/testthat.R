library(testthat)
library(KoNLP)
options(encoding="UTF-8")

test_check("KoNLP")

